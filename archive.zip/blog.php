<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
 echo "hello world this is php "
?>
</body>
</html>